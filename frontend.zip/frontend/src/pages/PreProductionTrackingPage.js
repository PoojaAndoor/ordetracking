import React, { useEffect, useState } from "react";
import "./PreProductionTrackingPage.css";

console.log("PreProductionTrackingPage loaded");

const PreProductionTrackingPage = ({ onGoBack }) => {
    const [trackingData, setTrackingData] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    // Fetch orders with milestones from the backend (Only once on component mount)
    useEffect(() => {
        const fetchTrackingData = async () => {
            try {
                const response = await fetch("http://localhost:3006/ordertracking/orders/milestones");
                const data = await response.json();
                console.log("Fetched tracking data:", data);
                setTrackingData(data);
            } catch (error) {
                console.error("Error fetching tracking data:", error);
                setError(error);
            } finally {
                setLoading(false);
            }
        };

        fetchTrackingData();
    }, []); // Empty dependency array ensures it runs only once

    // Table Headers
    const headers = [
        "Season", "Style", "OrderNo", "Buyer", "QTY", "Ex-Factry", "Ord Rcvd", "Bom Gen",
        "SizeSet App", "PP Smpl Cmp", "Fab Ord", "Trims Ord", "Fab Rcvd", "Trims Rcvd",
        "PP Mtg", "Owner"
    ];

    if (loading) return <p>Loading Pre-Production Tracking...</p>;
    if (error) return <p>Error loading data.</p>;

    return (
        <div className="preproduction-container">
            {/* Header Section with Back Button */}
            <div className="header">
                <button className="back-button" onClick={onGoBack}>
                    ⬅ Back
                </button>
                <span className="header-text">Pre-Production Tracking</span>
            </div>

            <div className="table-container">
                <table className="preproduction-table">
                    <thead>
                        <tr>
                            {headers.map((header, index) => (
                                <th key={index}>{header}</th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {trackingData.map((order, index) => (
                            <tr key={index}>
                                <td>{order.season}</td>
                                <td style={{ color: "blue" }}>{order.style}</td>
                                <td>{order.orderNo}</td>
                                <td>{order.buyer || "-"}</td>
                                <td>{order.quantity || "-"}</td>
                                <td>{order.milestones["Ex-Factry"].value || "-"}</td>
                                {headers.slice(6, -1).map((header, idx) => (
                                    <td
                                        key={idx}
                                        style={{ backgroundColor: order.milestones[header]["status"] === 'D' ? 'red' : order.milestones[header]["status"] === 'O' ? 'orange' : order.milestones[header]["status"] === 'L' ? 'green' : 'inherit' }}
                                    >
                                        {order.milestones[header].value || "-"}
                                    </td>
                                ))}
                                <td>{order.owner || "-"}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default PreProductionTrackingPage;
