// // import React, { useEffect, useState } from "react";
// // import {
// //   Table,
// //   Input,
// //   Button,
// //   Modal,
// //   Form,
// //   DatePicker,
// //   message,
// //   Popconfirm,
// // } from "antd";
// // import {
// //   SearchOutlined,
// //   PlusCircleFilled,
// //   MenuOutlined,
// //   ArrowRightOutlined,
// // } from "@ant-design/icons";
// // import axios from "axios";
// // import "../App.css";
// // import { useNavigate } from "react-router-dom";

// // const OrderPage = () => {
// //   const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
// //   const [form] = Form.useForm();
// //   const [orders, setOrders] = useState([]);
// //   const navigate = useNavigate();

// //   useEffect(() => {
// //     fetchOrders();
// //   }, []);

// //   const fetchOrders = async () => {
// //     try {
// //       const response = await axios.get("http://localhost:3006/orders");
// //       setOrders(response.data);
// //     } catch (error) {
// //       console.error("Error fetching orders:", error);
// //       message.error("Failed to fetch orders!");
// //     }
// //   };

// //   const handleActionClick = (order) => {
// //     navigate(`/ordertracking/${order.order_no}`);
// //   };

// //   const handleSave = async () => {
// //     try {
// //       const values = await form.validateFields();
// //       const formattedValues = {
// //         ...values,
// //         exfac_date: values.exfac_date
// //           ? values.exfac_date.format("YYYY-MM-DD")
// //           : null,
// //       };

// //       const response = await axios.post(
// //         "http://localhost:3006/orders",
// //         formattedValues,
// //         {
// //           headers: { "Content-Type": "application/json" },
// //         }
// //       );

// //       if (response.status === 200 || response.status === 201) {
// //         message.success("Order saved successfully!");
// //         fetchOrders();
// //         setIsOrderModalOpen(false);
// //         form.resetFields();
// //       } else {
// //         message.error("Failed to save order.");
// //       }
// //     } catch (error) {
// //       console.error(
// //         "Error saving order:",
// //         error.response?.data || error.message
// //       );
// //       message.error("Error saving order. Check console for details.");
// //     }
// //   };

// //   const handleDelete = async (order_no) => {
// //     try {
// //       const response = await axios.delete(
// //         `http://localhost:3006/orders/${order_no}`
// //       );

// //       if (response.data.success) {
// //         message.success("Order deleted successfully!");
// //         fetchOrders();
// //         setOrders((prevOrders) =>
// //           prevOrders.filter((order) => order.order_no !== order_no)
// //         );
// //       } else {
// //         message.error("Failed to delete order.");
// //       }
// //     } catch (error) {
// //       console.error("Error deleting order:", error);
// //       message.error("Error deleting order: " + error.message);
// //     }
// //   };

// //   const showModal = () => {
// //     setIsOrderModalOpen(true);
// //   };

// //   const handleCancel = () => {
// //     setIsOrderModalOpen(false);
// //   };

// //   const columns = [
// //     { title: "Season", dataIndex: "season", key: "season" },
// //     { title: "Style", dataIndex: "style", key: "style" },
// //     { title: "Order No", dataIndex: "order_no", key: "order_no" },
// //     { title: "Buyer", dataIndex: "buyer", key: "buyer" },
// //     { title: "Quantity", dataIndex: "quantity", key: "quantity" },
// //     { title: "ExFac Date", dataIndex: "exfac_date", key: "exfac_date" },
// //     { title: "Status", dataIndex: "status", key: "status" },
// //     { title: "Owner", dataIndex: "owner", key: "owner" },
// //     {
// //       title: "Action",
// //       key: "action",
// //       render: (_, record) => (
// //         <div style={{ display: "flex", gap: "10px" }}>
// //           <Button
// //             type="link"
// //             icon={<ArrowRightOutlined />}
// //             onClick={() => handleActionClick(record)}
// //           />
// //           <Popconfirm
// //             title="Are you sure you want to delete this order?"
// //             onConfirm={() => handleDelete(record.order_no)}
// //             okText="Yes"
// //             cancelText="No"
// //           >
// //             <Button type="primary" danger>
// //               Delete
// //             </Button>
// //           </Popconfirm>
// //         </div>
// //       ),
// //     },
// //   ];

// //   return (
// //     <div className="order-page">
// //       <div className="header">
// //         <MenuOutlined className="menu-icon" />
// //         <span className="title">All Orders</span>
// //         <Input
// //           placeholder="Search orders..."
// //           prefix={<SearchOutlined />}
// //           className="search-bar"
// //         />
// //         <Button
// //           type="primary"
// //           shape="circle"
// //           icon={<PlusCircleFilled />}
// //           className="add-button"
// //           onClick={showModal}
// //         />
// //       </div>

// //       <div className="table-container">
// //         <Table
// //           columns={columns}
// //           dataSource={orders}
// //           rowKey="order_no"
// //           pagination={false}
// //         />
// //       </div>

// //       <Modal
// //         title="Add Order"
// //         open={isOrderModalOpen}
// //         onCancel={handleCancel}
// //         footer={[
// //           <Button key="cancel" onClick={handleCancel}>
// //             Cancel
// //           </Button>,
// //           <Button key="save" type="primary" onClick={handleSave}>
// //             Save
// //           </Button>,
// //         ]}
// //       >
// //         <Form form={form} layout="vertical">
// //           <Form.Item
// //             label="Season"
// //             name="season"
// //             rules={[{ required: true, message: "Please enter season!" }]}
// //           >
// //             <Input />
// //           </Form.Item>
// //           <Form.Item
// //             label="Style"
// //             name="style"
// //             rules={[{ required: true, message: "Please enter style!" }]}
// //           >
// //             <Input />
// //           </Form.Item>
// //           <Form.Item
// //             label="Order No"
// //             name="order_no"
// //             rules={[{ required: true, message: "Please enter order number!" }]}
// //           >
// //             <Input />
// //           </Form.Item>
// //           <Form.Item
// //             label="Buyer"
// //             name="buyer"
// //             rules={[{ required: true, message: "Please enter buyer!" }]}
// //           >
// //             <Input />
// //           </Form.Item>
// //           <Form.Item
// //             label="Quantity"
// //             name="quantity"
// //             rules={[{ required: true, message: "Please enter quantity!" }]}
// //           >
// //             <Input type="number" />
// //           </Form.Item>
// //           <Form.Item label="ExFac Date" name="exfac_date">
// //             <DatePicker />
// //           </Form.Item>
          
// //           <Form.Item
// //             label="Owner"
// //             name="owner"
// //             rules={[{ required: true, message: "Please enter the owner!" }]}
// //           >
// //             <Input placeholder="Enter Owner Email" />
// //           </Form.Item>
// //         </Form>
// //       </Modal>
// //     </div>
// //   );
// // };

// // export default OrderPage;
// import React, { useEffect, useState } from "react";
// import {
//   Table,
//   Input,
//   Button,
//   Modal,
//   Form,
//   DatePicker,
//   message,
//   Popconfirm,
// } from "antd";
// import {
//   SearchOutlined,
//   PlusCircleFilled,
//   MenuOutlined,
//   ArrowRightOutlined,
// } from "@ant-design/icons";
// import axios from "axios";
// import "../App.css";
// import { useNavigate } from "react-router-dom";

// const OrderPage = () => {
//   const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
//   const [form] = Form.useForm();
//   const [orders, setOrders] = useState([]);
//   const navigate = useNavigate();

//   useEffect(() => {
//     fetchOrders();
//   }, []);

//   const fetchOrders = async () => {
//     try {
//       const response = await axios.get("http://localhost:3006/orders");
//       setOrders(response.data);
//     } catch (error) {
//       console.error("Error fetching orders:", error);
//       message.error("Failed to fetch orders!");
//     }
//   };

//   const handleActionClick = (order) => {
//     navigate(`/ordertracking/${order.order_no}`);
//   };

//   const handleSave = async () => {
//     try {
//       const values = await form.validateFields();
//       const formattedValues = {
//         ...values,
//         exfac_date: values.exfac_date
//           ? values.exfac_date.format("YYYY-MM-DD")
//           : null,
//       };

//       const response = await axios.post(
//         "http://localhost:3006/orders",
//         formattedValues,
//         {
//           headers: { "Content-Type": "application/json" },
//         }
//       );

//       if (response.status === 200 || response.status === 201) {
//         message.success("Order saved successfully!");
//         fetchOrders();
//         setIsOrderModalOpen(false);
//         form.resetFields();
//       } else {
//         message.error("Failed to save order.");
//       }
//     } catch (error) {
//       console.error(
//         "Error saving order:",
//         error.response?.data || error.message
//       );
//       message.error("Error saving order. Check console for details.");
//     }
//   };

//   const handleDelete = async (order_no) => {
//     try {
//       const response = await axios.delete(
//         `http://localhost:3006/orders/${order_no}`
//       );

//       if (response.data.success) {
//         message.success("Order deleted successfully!");
//         fetchOrders();
//         setOrders((prevOrders) =>
//           prevOrders.filter((order) => order.order_no !== order_no)
//         );
//       } else {
//         message.error("Failed to delete order.");
//       }
//     } catch (error) {
//       console.error("Error deleting order:", error);
//       message.error("Error deleting order: " + error.message);
//     }
//   };

//   const showModal = () => {
//     setIsOrderModalOpen(true);
//   };

//   const handleCancel = () => {
//     setIsOrderModalOpen(false);
//   };

//   const handlePlanningClick = () => {
//     alert("Planning button clicked!");
//   };

//   const columns = [
//     { title: "Season", dataIndex: "season", key: "season" },
//     { title: "Style", dataIndex: "style", key: "style" },
//     { title: "Order No", dataIndex: "order_no", key: "order_no" },
//     { title: "Buyer", dataIndex: "buyer", key: "buyer" },
//     { title: "Quantity", dataIndex: "quantity", key: "quantity" },
//     { title: "ExFac Date", dataIndex: "exfac_date", key: "exfac_date" },
//     { title: "Status", dataIndex: "status", key: "status" },
//     { title: "Owner", dataIndex: "owner", key: "owner" },
//     {
//       title: "Action",
//       key: "action",
//       render: (_, record) => (
//         <div style={{ display: "flex", gap: "10px" }}>
//           <Button
//             type="link"
//             icon={<ArrowRightOutlined />}
//             onClick={() => handleActionClick(record)}
//           />
//           <Popconfirm
//             title="Are you sure you want to delete this order?"
//             onConfirm={() => handleDelete(record.order_no)}
//             okText="Yes"
//             cancelText="No"
//           >
//             <Button type="primary" danger>
//               Delete
//             </Button>
//           </Popconfirm>
//         </div>
//       ),
//     },
//   ];

//   return (
//     <div className="order-page">
//       <div className="header">
//         <MenuOutlined className="menu-icon" />
//         <span className="title">All Orders</span>
//         <Input
//           placeholder="Search orders..."
//           prefix={<SearchOutlined />}
//           className="search-bar"
//         />
//         <Button type="primary" onClick={handlePlanningClick} className="planning-button">
//           Planning
//         </Button>
//         <Button
//           type="primary"
//           shape="circle"
//           icon={<PlusCircleFilled />}
//           className="add-button"
//           onClick={showModal}
//         />
//       </div>

//       <div className="table-container">
//         <Table
//           columns={columns}
//           dataSource={orders}
//           rowKey="order_no"
//           pagination={false}
//         />
//       </div>

//       <Modal
//         title="Add Order"
//         open={isOrderModalOpen}
//         onCancel={handleCancel}
//         footer={[
//           <Button key="cancel" onClick={handleCancel}>
//             Cancel
//           </Button>,
//           <Button key="save" type="primary" onClick={handleSave}>
//             Save
//           </Button>,
//         ]}
//       >
//         <Form form={form} layout="vertical">
//           <Form.Item label="Season" name="season" rules={[{ required: true, message: "Please enter season!" }]}>
//             <Input />
//           </Form.Item>
//           <Form.Item label="Style" name="style" rules={[{ required: true, message: "Please enter style!" }]}>
//             <Input />
//           </Form.Item>
//         </Form>
//       </Modal>
//     </div>
//   );
// };

// export default OrderPage;

import React, { useEffect, useState } from "react";
import { Table, Input, Button, Modal, Form, DatePicker, message, Popconfirm } from "antd";
import { SearchOutlined, PlusCircleFilled, MenuOutlined, ArrowRightOutlined } from "@ant-design/icons";
import axios from "axios";
import "../App.css";
import { useNavigate } from "react-router-dom";

const OrderPage = () => {
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [form] = Form.useForm();
  const [orders, setOrders] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const response = await axios.get("http://localhost:3006/orders");
      setOrders(response.data);
    } catch (error) {
      console.error("Error fetching orders:", error);
      message.error("Failed to fetch orders!");
    }
  };

  const handleActionClick = (order) => {
    navigate(`/ordertracking/${order.order_no}`);
  };

  const handleSave = async () => {
    try {
      const values = await form.validateFields();
      const formattedValues = {
        ...values,
        exfac_date: values.exfac_date ? values.exfac_date.format("YYYY-MM-DD") : null,
      };

      const response = await axios.post("http://localhost:3006/orders", formattedValues, {
        headers: { "Content-Type": "application/json" },
      });

      if (response.status === 200 || response.status === 201) {
        message.success("Order saved successfully!");
        fetchOrders();
        setIsOrderModalOpen(false);
        form.resetFields();
      } else {
        message.error("Failed to save order.");
      }
    } catch (error) {
      console.error("Error saving order:", error.response?.data || error.message);
      message.error("Error saving order. Check console for details.");
    }
  };

  const handleDelete = async (order_no) => {
    try {
      const response = await axios.delete(`http://localhost:3006/orders/${order_no}`);

      if (response.data.success) {
        message.success("Order deleted successfully!");
        fetchOrders();
        setOrders((prevOrders) => prevOrders.filter((order) => order.order_no !== order_no));
      } else {
        message.error("Failed to delete order.");
      }
    } catch (error) {
      console.error("Error deleting order:", error);
      message.error("Error deleting order: " + error.message);
    }
  };

  const showModal = () => {
    setIsOrderModalOpen(true);
  };

  const handleCancel = () => {
    setIsOrderModalOpen(false);
  };

  const handlePlanningClick = () => {
    navigate("/preproductiontracking");
  };

  const columns = [
    { title: "Season", dataIndex: "season", key: "season" },
    { title: "Style", dataIndex: "style", key: "style" },
    { title: "Order No", dataIndex: "order_no", key: "order_no" },
    { title: "Buyer", dataIndex: "buyer", key: "buyer" },
    { title: "Quantity", dataIndex: "quantity", key: "quantity" },
    { title: "ExFac Date", dataIndex: "exfac_date", key: "exfac_date" },
    { title: "Status", dataIndex: "status", key: "status" },
    { title: "Owner", dataIndex: "owner", key: "owner" },
    {
      title: "Action",
      key: "action",
      render: (_, record) => (
        <div style={{ display: "flex", gap: "10px" }}>
          <Button type="link" icon={<ArrowRightOutlined />} onClick={() => handleActionClick(record)} />
          <Popconfirm
            title="Are you sure you want to delete this order?"
            onConfirm={() => handleDelete(record.order_no)}
            okText="Yes"
            cancelText="No"
          >
            <Button type="primary" danger>
              Delete
            </Button>
          </Popconfirm>
        </div>
      ),
    },
  ];

  return (
    <div className="order-page">
      <div className="header">
        <MenuOutlined className="menu-icon" />
        <span className="title">All Orders</span>
        <Input placeholder="Search orders..." prefix={<SearchOutlined />} className="search-bar" />
        
        {/* Planning Button */}
        <Button type="primary" onClick={handlePlanningClick} className="planning-button">
          Planning
        </Button>

        <Button type="primary" shape="circle" icon={<PlusCircleFilled />} className="add-button" onClick={showModal} />
      </div>

      <div className="table-container">
        <Table columns={columns} dataSource={orders} rowKey="order_no" pagination={false} />
      </div>

      <Modal
        title="Add Order"
        open={isOrderModalOpen}
        onCancel={handleCancel}
        footer={[
          <Button key="cancel" onClick={handleCancel}>
            Cancel
          </Button>,
          <Button key="save" type="primary" onClick={handleSave}>
            Save
          </Button>,
        ]}
      >
        <Form form={form} layout="vertical">
          <Form.Item label="Season" name="season" rules={[{ required: true, message: "Please enter season!" }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Style" name="style" rules={[{ required: true, message: "Please enter style!" }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Order No" name="order_no" rules={[{ required: true, message: "Please enter order number!" }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Buyer" name="buyer" rules={[{ required: true, message: "Please enter buyer!" }]}>
            <Input />
          </Form.Item>
          <Form.Item label="Quantity" name="quantity" rules={[{ required: true, message: "Please enter quantity!" }]}>
            <Input type="number" />
          </Form.Item>
          <Form.Item label="ExFac Date" name="exfac_date">
            <DatePicker />
          </Form.Item>
          <Form.Item label="Owner" name="owner" rules={[{ required: true, message: "Please enter the owner!" }]}>
            <Input placeholder="Enter Owner Email" />
          </Form.Item>
        </Form>
      </Modal>
    </div>
  );
};

export default OrderPage;
