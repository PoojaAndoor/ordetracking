import React, { useEffect, useState, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Table, Button, DatePicker, Select, Checkbox, Spin } from "antd";
import axios from "axios";
import dayjs from "dayjs";

const { Option } = Select;

const OrderTrackingPage = () => {
  const { order_no } = useParams();
  const [milestones, setMilestones] = useState([]);
  const [selectedTasks, setSelectedTasks] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const hasFetched = useRef(false);

  useEffect(() => {
    fetchMilestones(order_no);
    hasFetched.current = false; // Reset flag on order change
  }, [order_no]);

  const fetchMilestones = async (customer) => {
    try {
      const response = await axios.get(`http://localhost:3006/ordertracking/${customer}`);
      setMilestones(response.data);
      setSelectedTasks(response.data.filter((item) => item.SecondaryStatus).map((item) => item.ID));
    } catch (error) {
      console.error("Error fetching milestones:", error);
    }
  };

  const handleEditChange = (value, key, record) => {
    setMilestones((prev) =>
      prev.map((item) => (item.ID === record.ID ? { ...item, [key]: value } : item))
    );
  };

  const saveData = async (data) => {
    try {
      await axios.put(`http://localhost:3006/ordertracking/${data.ID}`, data);
      fetchMilestones(order_no);
    } catch (error) {
      console.log(error);
    }
  };

  const handleCheckboxChange = (checked, record) => {
    setSelectedTasks((prev) =>
      checked ? [...prev, record.ID] : prev.filter((id) => id !== record.ID)
    );
  };

  const handleSubmitSelectedTasks = async () => {
    try {
      const selectedTaskData = milestones.filter((item) => selectedTasks.includes(item.ID));
      await axios.post("http://localhost:3006/tasktracking", { tasks: selectedTaskData });
      alert("Selected tasks updated successfully!");
    } catch (error) {
      console.error("Error saving selected tasks:", error);
      alert("Failed to update selected tasks.");
    }
  };

  const orderTrackingColumns = [
    {
      title: "Select",
      dataIndex: "SecondaryStatus",
      key: "SecondaryStatus",
      render: (text, record) => (
        <Checkbox
          checked={selectedTasks.includes(record.ID)}
          onChange={(e) => handleCheckboxChange(e.target.checked, record)}
        />
      ),
    },
    { title: "Milestone ID", dataIndex: "ID", key: "ID" },
    { title: "Milestone", dataIndex: "Milestone", key: "Milestone" },
    { title: "Task Description", dataIndex: "TaskDescription", key: "TaskDescription" },
    { title: "Department", dataIndex: "Department", key: "Department" },
    {
      title: "Milestone Date",
      dataIndex: "MilestoneDate",
      key: "MilestoneDate",
      render: (text, record) => (
        <DatePicker
          value={text ? dayjs(text) : null}
          onChange={(date, dateString) => handleEditChange(dateString, "MilestoneDate", record)}
        />
      ),
    },
    { title: "Lead Time", dataIndex: "Leadtime", key: "Leadtime" },
    {
      title: "Status",
      dataIndex: "Status",
      key: "Status",
      render: (text, record) => (
        <Select
          value={text}
          onChange={(value) => handleEditChange(value, "Status", record)}
          style={{ width: 120 }}
        >
          <Option value="Pending">Pending</Option>
          <Option value="In Progress">In Progress</Option>
          <Option value="Completed">Completed</Option>
        </Select>
      ),
    },
    {
      title: "",
      dataIndex: "Save",
      key: "Save",
      render: (text, record) => <Button onClick={() => saveData(record)}>Save</Button>,
    },
  ];

  return (
    <div className="tracking-page">
      <div className="header">
        <Button onClick={() => navigate(-1)}>Go Back</Button>
        <span>Tracking Order: {order_no}</span>

        {/* ✅ Navigate to Task Tracking Page */}
        <Button
          style={{ marginLeft: "auto", backgroundColor: "green", color: "white", marginRight: "10px" }}
          onClick={() => navigate(`/task-tracking`)}
        >
          Task Tracking
        </Button>

        <Button
          style={{ backgroundColor: "blue", color: "white" }}
          onClick={handleSubmitSelectedTasks}
        >
          Submit Selected Tasks
        </Button>
      </div>

      {/* ✅ Order Tracking Table */}
      <Table columns={orderTrackingColumns} dataSource={milestones} pagination={false} rowKey="ID" />
    </div>
  );
};

export default OrderTrackingPage;
