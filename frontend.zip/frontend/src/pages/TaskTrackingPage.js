import React, { useEffect, useState, useRef } from "react";
import { Table } from "antd";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./TaskTrackingPage.css";

const TaskTrackingPage = () => {
  const [taskTrackingData, setTaskTrackingData] = useState([]);
  const [taskTrackingColumns, setTaskTrackingColumns] = useState([]);
  const [showTaskTracking, setShowTaskTracking] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const hasFetched = useRef(false);
  const navigate = useNavigate();

  useEffect(() => {
    fetchTaskTracking();
  }, []);

  // ✅ Function to generate random STATUSCODE
  // const getRandomStatusCode = () => {
  //   const statusCodes = ["D", "L", "O", "Null"];
  //   return statusCodes[Math.floor(Math.random() * statusCodes.length)];
  // };

  // ✅ Fetch Task Tracking Data
  const fetchTaskTracking = async () => {
    if (isLoading || hasFetched.current) return;

    try {
      console.log("Fetching task tracking data...");
      setIsLoading(true);
      hasFetched.current = true;

      const response = await axios.get("http://localhost:3006/tasktracking");

      if (!response.data || response.data.length === 0) {
        alert("No Task Tracking data found.");
        setTaskTrackingData([]);
        setShowTaskTracking(false);
      } else {
        console.log("API Response Data:", response.data); // Debugging

        // ✅ Fill empty STATUSCODE values
        // const updatedData = response.data.map((item) => {
        //   item.StatusCode = item.StatusCode.trim() !== "" ? item.StatusCode : getRandomStatusCode();
        //   return item;
        // });

        // console.log("Updated Data with STATUSCODE:", updatedData);

        setTaskTrackingData(response.data);

        // ✅ Define columns with STATUSCODE background color formatting
        const columns = Object.keys(response.data[0] || {}).map((key) => ({
          title: key.replace(/_/g, " ").toUpperCase(),
          dataIndex: key,
          key: key,
          render: (text) => {
            if (key === "STATUSCODE") {
              let backgroundColor = "transparent";

              if (text === "D") backgroundColor = "red";
              else if (text === "L") backgroundColor = "orange";
              else if (text === "O") backgroundColor = "green";
              else if (text === "Null") backgroundColor = "#ccc";

              return {
                props: {
                  style: {
                    backgroundColor,
                    color: "white",
                    textAlign: "center",
                    fontWeight: "bold",
                  },
                },
                children: text,
              };
            }
            return text;
          },
        }));

        setTaskTrackingColumns(columns);
        setShowTaskTracking(true);
      }
    } catch (error) {
      console.error("Error fetching task tracking data:", error);
      alert("Failed to fetch task tracking data.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        style={{
          marginBottom: "10px",
          padding: "4px 8px",
          backgroundColor: "#007bff",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
          fontSize: "16px",
        }}
      >
        ⬅ Back
      </button>

      {showTaskTracking && taskTrackingData.length > 0 && (
        <>
          <h3 style={{ marginTop: "20px" }}>Task Tracking Table</h3>
          <Table
            columns={taskTrackingColumns}
            dataSource={taskTrackingData}
            pagination={false}
            rowKey="ID"
            scroll={{ x: "max-content" }}
            bordered
            className="custom-task-table"
          />
        </>
      )}
    </div>
  );
};

export default TaskTrackingPage;
