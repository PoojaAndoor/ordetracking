// const express = require('express');
// const passport = require('passport');

// const router = express.Router();

// // Google authentication routes
// router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));
// router.get('/google/callback', 
//     passport.authenticate('google', { failureRedirect: '/' }),
//     (req, res) => {
//         res.redirect('/dashboard');
//     }
// );

// // Microsoft authentication routes
// router.get('/microsoft', passport.authenticate('microsoft'));
// router.get('/microsoft/callback',
//     passport.authenticate('microsoft', { failureRedirect: '/' }),
//     (req, res) => {
//         res.redirect('/dashboard');
//     }
// );

// router.get('/logout', (req, res) => {
//     req.logout(() => {
//         res.redirect('/');
//     });
// });

// module.exports = router;
