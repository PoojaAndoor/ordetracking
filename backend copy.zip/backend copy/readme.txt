1. alter the order table - alter table orders add column user_id varchar(36);
2. have two users in user table with different email and user_id.
2. add a random user_id (dfd68a26-7943-4ff5-818b-9760c16551cb) in user table as well as orders table.
3. In order table add this user_id from some three order and add another random user_id for balance orders.
4. once a new login completed via login with google next time login with your email as username 
   and 12345678 as default password for all users.
5. then it will show the orders list based on your user if you want to see the another user 
   order logout and login with second user email.



  