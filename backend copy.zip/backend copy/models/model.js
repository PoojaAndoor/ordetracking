const { DataTypes, Sequelize } = require("sequelize");
const sequelize = require("../sequelizeInstance");

const Milestone = sequelize.define('Milestone', {
    MilestoneID: {
        type: DataTypes.STRING,
        primaryKey: true,
        allowNull: false,
    },
    MilestonSeqNum: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    Customer: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    Milestone: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    TaskDescription: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    Leadtime: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 0,
    },
    WashLT: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 0,
    },
    Department: {
        type: DataTypes.STRING,
        allowNull: false,
    },
}, {
    tableName: 'Milestones',
    timestamps: false,
});

const Order = sequelize.define('Order', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
        allowNull: false,
    },
    season: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    style: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    order_no: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
    },
    buyer: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    quantity: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    exfac_date: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    owner: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    status: {
        type: DataTypes.STRING(50),
        allowNull: true,
        defaultValue: 'Pending',
    },
}, {
    tableName: 'orders',
    timestamps: false,
});

const OrderTracking = sequelize.define('OrderTracking', {
    ID: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: false,
    },
    OrderNo: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    Customer: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    OrderQty: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    ExFacDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Milestone: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    MilestonSeqNum: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    TaskDescription: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    Leadtime: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    CalculatedDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    ApprovedDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    MilestoneDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Department: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    Status: {
        type: DataTypes.STRING(50),
        allowNull: true,
        defaultValue: 'Pending',
    },
    StatusCode: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },
    DelayDays: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    DelayReason: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    Createdate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Owner: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    Stage: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    ApprLeadTime: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    ApprDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    SecondaryStatus: {
        type: DataTypes.BOOLEAN,
        defaultValue: true
    }
}, {
    tableName: 'ordertracking',
    timestamps: false
});

const User = sequelize.define('User', {
    user_id: {
        type: DataTypes.UUID,
        primaryKey: true,
        unique: true,
        defaultValue: DataTypes.UUIDV4
    },
    googleId: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false
    },
    displayName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    profilePic: {
        type: DataTypes.STRING
    }
});

Order.hasMany(OrderTracking, { foreignKey: 'OrderNo', sourceKey: 'order_no' });
OrderTracking.belongsTo(Order, { foreignKey: 'OrderNo', targetKey: 'order_no' });
// OrderTracking.hasMany(Milestone, { foreignKey: 'MilestonSeqNum', sourceKey: 'MilestonSeqNum' });
// Milestone.belongsTo(OrderTracking, { foreignKey: 'MilestonSeqNum', targetKey: 'MilestonSeqNum' });

const TaskTracking = sequelize.define('TaskTracking', {
    ID: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: false,
    },
    OrderNo: {
        type: DataTypes.STRING(50),
        allowNull: false,
    },
    Customer: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    OrderQty: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    ExFacDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Milestone: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    MilestonSeqNum: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    TaskDescription: {
        type: DataTypes.STRING(255),
        allowNull: false,
    },
    Leadtime: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    CalculatedDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    ApprovedDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    MilestoneDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Department: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    Status: {
        type: DataTypes.STRING(50),
        allowNull: true,
        defaultValue: 'Pending',
    },
    StatusCode: {
        type: DataTypes.STRING(10),
        allowNull: true,
    },
    DelayDays: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 0,
    },
    DelayReason: {
        type: DataTypes.TEXT,
        allowNull: true,
    },
    Createdate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
    Owner: {
        type: DataTypes.STRING(100),
        allowNull: false,
    },
    Stage: {
        type: DataTypes.STRING(100),
        allowNull: true,
    },
    ApprLeadTime: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    ApprDate: {
        type: DataTypes.DATEONLY,
        allowNull: false,
    },
}, {
    tableName: 'task_tracking',
    timestamps: false
});

module.exports = {
    Milestone: Milestone,
    Order: Order,
    OrderTracking: OrderTracking,
    User: User,
    TaskTracking: TaskTracking
}
